L1 = [12, 23, 123, 5, 2345, 6]
L1.reverse()
print(L1)
